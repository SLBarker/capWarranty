sap.ui.define(["sap/fe/core/PageController"],function(e){"use strict";return e.extend("capwarrantygui.ext.main.Main",{})});
//# sourceMappingURL=Main.controller.js.map